import numpy as np
import cv2 
from matplotlib import pyplot as plt
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import os
import pandas as pd
img = cv2.imread('new.png',0)
# Now we split the image to 5000 cells, each 20x20 size
cells = [np.hsplit(row,105) for row in np.vsplit(img,36)]
# Make it into a Numpy array. It size will be (50,100,20,20)
x = np.array(cells)
# Now we prepare train_data and test_data.
train = x[:,:80].reshape(-1,784).astype(np.float32) # Size = (2500,400)
#train = train.reshape(-1,360)
test = x[:,80:105].reshape(-1,784).astype(np.float32) # Size = (2500,400)
#test = test.reshape(-1,180)
# Create labels for train and test data
k = np.arange(36)
train_labels = np.repeat(k,80)[:,np.newaxis]
test_labels = np.repeat(k,25)[:,np.newaxis]
#train_labels = pd.get_dummies(train_labels) #将测试集标签进行one-hot编码
#test_labels = pd.get_dummies(test_labels) #将测试集标签进行one-hot编码
print(train[1])
print("训练集标签的形状：", train_labels.shape,'\n'
      "训练集标签的总数：", train_labels.size,'\n'
      "训练集标签的维度：", train_labels.ndim,'\n') #用于查看标签信息
print("测试集标签的形状：",test_labels.shape,'\n'
      "测试集标签的总数：",test_labels.size,'\n'
      "测试集标签的维度：",test_labels.ndim,'\n') #用于查看标签信息
# 初始化kNN，训练数据，然后使用k = 1的测试数据对其进行测试
knn = cv2.ml.KNearest_create()
knn.train(train, cv2.ml.ROW_SAMPLE, train_labels)
ret,result,neighbours,dist = knn.findNearest(test,k=5)
# 现在，我们检查分类的准确性
#为此，将结果与test_labels进行比较，并检查哪个错误
matches = result==test_labels
correct = np.count_nonzero(matches)
accuracy = correct*100.0/result.size
print( accuracy )
# 保存数据
np.savez('knn_data.npz',train=train, train_labels=train_labels,test=test)
# 现在加载数据
with np.load('knn_data.npz') as data:
    print( data.files )
    train = data['train']
    train_labels = data['train_labels']
